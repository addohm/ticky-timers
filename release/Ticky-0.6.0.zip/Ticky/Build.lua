local ADDON, ns = ...

-- Which build this is: the commit this package was made from (the repo copy says "dev").
ns.Build = "694e496"
